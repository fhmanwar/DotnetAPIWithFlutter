﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using API.Context;
using API.Models;
using API.Repository;
using API.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TransactionsController : ControllerBase
    {
        private readonly MyContext _context;
        public IConfiguration _configuration;
        TransactionRepo _repo;

        public TransactionsController(MyContext myContext, IConfiguration config, TransactionRepo repo)
        {
            _context = myContext;
            _configuration = config;
            _repo = repo;
        }

        [HttpGet]
        public async Task<IEnumerable<TransactionVM>> GetAll() => await _repo.getAll();

        [HttpGet("{id}")]
        public TransactionVM GetID(int id) => _repo.getID(id);

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] TransactionVM dataVM)
        {
            try
            {
                // do whatever you want to do with the yourDto object
                var dataT = new TransactionVM
                {
                    UserId = dataVM.UserId,
                    OrderDate = dataVM.OrderDate,
                    Total = dataVM.Total,
                };
                var create = _repo.Create(dataT);
                if (create > 0)
                {
                    var getTransactionId = _context.Transactions.SingleOrDefault(x => x.UserId == dataVM.UserId && x.OrderDate == dataVM.OrderDate);
                    //List<TransactionItem> newDatas = new List<TransactionItem>();
                    foreach (TransactionItemVM ti in dataVM.transactionItems)
                    {
                        var data = new TransactionItem {
                            TransactionId = getTransactionId.TransactionId,
                            ProductId = ti.ProductId,
                            Quantity = ti.Quantity,
                            SubTotal = ti.SubTotal,
                        };
                        await _context.TransactionItems.AddAsync(data);
                        
                    }
                    _context.SaveChanges();


                    return Ok("Successfully Created");
                }
                return BadRequest("Input User Not Successfully");
            }
            catch (Exception ex)
            {
                return StatusCode(500, ex);
            }
            //var getUser = _context.Products.Where(x => x.ProductName == getDataVM.ProductName);
            //if (getUser.Count() == 0)
            //{
            //    if (ModelState.IsValid)
            //    {
            //        var getCatId = _context.Categories.SingleOrDefault(x => x.CategoryName == getDataVM.CategoryName);
            //        var data = new Product
            //        {
            //            ProductName = getDataVM.ProductName,
            //            Stock = getDataVM.Stock,
            //            Price = getDataVM.Price,
            //            Unit = getDataVM.Unit,
            //            CategoryId = getCatId.CategoryId,
            //        };
            //        _context.Products.Add(data);
            //        _context.SaveChanges();

            //        return Ok("Successfully Created");
            //    }
            //    return BadRequest("Not Successfully");
            //}
            //return BadRequest("Name Already Exists ");
        }
    }
}
